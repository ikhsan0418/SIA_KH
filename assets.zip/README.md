# kas-php-native
Aplikasi website sederhana pengelola kas sekolah 

<p>Aplikasi website berita sederhana yang di buat dengan bahasa program php, javascript, dan menggunakan DBMS (mysql)</p>
<br>
<h3>Fitur Pengeloa Admin Website</h3>
<ul>
	<li>Kas Masuk</li>
	<li>Kas Keluar</li>
	<li>Rekapitulasi</li>
	<li>Management Users</li>
  <li>Perpanjang masa pinjam buku</li>
  <li>Login, Registrasi & Logout</li>
  <li>Cetak/Print</li>
  <li>Hak akses menu admin & user.</li>
</ul>
<br>
<h3>Penjelasan</h3>
1. Website ini sangat masih sederhana, sehingga anda bisa mengembangkannya lagi.

2. Semua Gratis source yang saya berikan kepada anda.
