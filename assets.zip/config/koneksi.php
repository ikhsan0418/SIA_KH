<?php 
$conn = new mysqli("localhost", "root", "", "kas_native") or die(mysqli_error($conn));

?>